此为ailearn人工智能算法包。包含了Swarm、EAS、Evaluation三个模块。
Swarm模块当中，实现了粒子群算法、人工鱼群算法和萤火虫算法。
EAS模块当中，实现了进化策略。
Evaluation模块集成了一些对智能算法进行评估的常用待优化的函数。